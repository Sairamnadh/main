## References:
- [API Overview](https://kubernetes.io/docs/reference/using-api/)
- [API Reference](https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.22/)